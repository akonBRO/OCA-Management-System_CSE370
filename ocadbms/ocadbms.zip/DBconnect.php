<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Establish a database connection
$conn = new mysqli('sql104.infinityfree.com', 'if0_37960572', 'Akon2024', 'if0_37960572_oca');

// Check for a connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
